<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" name="viewport" content="width=device-width">
    <title>Equipe</title>
    <script src="../js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body class"container-fluid">

    <!-- Carrega Menu Fixo-->
    <?php
    include_once("menu.php");
    ?>

    <section>


    </section>
</body>
</html>
