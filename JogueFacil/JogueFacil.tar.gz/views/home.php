<section>
<center><p>Escolha um jogo. E voce será direcionado.</p></center>
    <center><p>Divirta-se!</p></center>

    <center>
        <li><a href="views/jogovelha.php"> <img src="img/logojv.png"><br>JOGO DA VELHA</a></li>
        <li><a href="views/jogomemoria.php"><img src="img/logojm.png"><br>JOGO DA MEMORIA</a></li>
        <li><a href="views/pong.php">Ping Pong Invidual</a></li>
        <li><a href="views/BatalhaNaval.php">Batalha Navaal</a></li>
        <li><a href="#">JOGO 5</a></li>
    </center>
</section>
