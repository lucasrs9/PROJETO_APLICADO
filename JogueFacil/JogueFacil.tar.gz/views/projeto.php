<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" name="viewport" content="width=device-width">
    <title>Projeto</title>
    <script src="../js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">

</head>
<body class"container-fluid">

    <!-- Carrega Menu Fixo-->
    <?php
    include_once("menu.php");
    ?>

    <section>
        <em><center><h1>Plataforma de Jogos Online</h1></center></em>
        <br>
        <br>
        <br>
        <br>
        <center>
            <p>Este projeto é desenvolvido pelos alunos do 5° Semestre do Curso de Sistemas de Informação do Centro Universitário Una</p>
            <p>A proposta do Projeto Aplicado é de desenvolver um projeto relacionado com a área de jogos.</p>
            <p>
                Com base nesta proposta, o nosso Projeto visa uma plataforma de jogos online que venha gerar entretenimento e pararelamente desenvolver o raciocíno lógico dos jogadores. <br>
                Aliando assim a diversão com aprendizado.
            </p>
        </center>

    </section>
</body>
</html>
